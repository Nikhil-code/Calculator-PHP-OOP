<?php

declare(strict_types = 1);
include "includes/autoloader.inc.php";


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link href="assets/fonts/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="container">
		<form action="includes/calc.inc.php" method="post">
			<p class="display-4 font-weight-bold font-italic text-primary" >My Own Calculator</p>
			<div class="form-group row">
				<label for="exampleInputEmail1" class="col-md-2">First Number</label>
				<input type="number" name="num1" class="col-md-4 form-control" id="exampleInputUser1" aria-describedby="userHelp">
			</div>
			<div class="form-group row">
				<label for="exampleInputEmail1" class="col-md-2">Second Number</label>
				<input type="number" name="num2" class="col-md-4 form-control" id="exampleInputUser1" aria-describedby="userHelp">
			</div>
			<div class="form-group row">
				<label for="methodSelect" class="col-md-2">Select Method</label>
				<select name="oper" class="col-md-4 form-control" id="methodSelect">
					<option value="add">Addition</option>
					<option value="sub">Substraction</option>
					<option value="div">Division</option>
					<option value="mul">Multiplication</option>
				</select>
			</div>
			<button type="submit" name="submit" class="btn btn-success">Calculate</button>
		</form>
	</div>


	<script src="assets/js/jquery-3.4.1.js"></script>
	<!-- Bootstrap core JavaScript -->
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>